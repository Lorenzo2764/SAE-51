# Serveur web de provisioning (FastAPI)

Deux services indépendants qui partagent le code de `commun/` et la base SAE-51 :

| Service | Rôle | Port local | Exposition |
|---|---|---|---|
| `portail` | espace client : connexion, configuration du routeur, IP fixe, téléchargement du .rsc | 8001 | Internet (DNAT 443) |
| `admin` | intranet : clients et routeurs autorisés | 8002 | intranet uniquement |

```
commun/   db.py (modèles SQLAlchemy) · validation.py · config_routeur.py (génération .rsc, écriture atomique)
          securite.py (bcrypt, CSRF, anti-force-brute, en-têtes) · service.py · erreurs.py · parametres.py
portail/  main.py        admin/  main.py        templates/ + static/   (HTML/CSS, sans JavaScript)
tests/    93 tests d'intégration (PostgreSQL)    deploy/  systemd, Apache, installation
```

## Principes
- **Aucune configuration n'est stockée en base.** La base ne contient que `clients` et `provisioning` (MAC, IP fixe, client). La page de configuration génère le fichier `<MAC>.rsc` à partir du formulaire, le dépose dans le dossier partagé (récupéré par le CPE en SFTP) et ne le relit jamais : le formulaire repart des valeurs par défaut à chaque visite.
- Le script RouterOS est idempotent (entrées marquées `comment="provisioning"`, supprimées puis recréées).
- Toute valeur écrite dans le script est validée strictement (`validation.py`) puis revalidée à la génération : pas d'injection de commande RouterOS.
- Le client peut saisir autant de redirections qu'il veut, sans unicité ni restriction de port ; seules la validité technique (protocole, ports 1-65535, IPv4) et un garde-fou de 100 lignes (`MAX_REDIRECTIONS`) subsistent.
- Sécurité : bcrypt, session signée HttpOnly/Secure/SameSite, jeton CSRF, 404 sur les routeurs d'autrui, anti-force-brute (5 échecs/15 min par IP et par e-mail), CSP stricte, Jinja2 en échappement automatique.

## Lancer les tests / en développement
```bash
pip install -r requirements.txt
export TEST_DATABASE_URL=postgresql+psycopg://web:MOT_DE_PASSE@127.0.0.1/SAE-51
python -m pytest -q tests          # vide provisioning/configurations/redirections !
export DATABASE_URL=$TEST_DATABASE_URL SESSION_SECRET=$(python -c "import secrets;print(secrets.token_urlsafe(48))") \
       CONFIGS_DIR=/tmp/configs COOKIE_SECURE=false
uvicorn portail.main:app --port 8001 & uvicorn admin.main:app --port 8002
```
Ne lancez pas les tests sur une base contenant des données à garder.

## Limites connues (à citer dans le rapport)
- Session sans état côté serveur : la déconnexion efface le cookie mais ne révoque pas un cookie volé avant son expiration (4 h).
- Anti-force-brute en mémoire : un seul processus uvicorn par service.
- L'administration n'a pas de compte applicatif : elle repose sur l'isolation réseau (Apache + absence de DNAT).
- Script RouterOS non testé sur un vrai CHR (syntaxe RouterOS 7).
